# lextab.py. This file automatically created by PLY (version 3.5). Don't edit!
_tabversion   = '3.5'
_lextokens    = {'RPAREN': 1, 'DIVIDE': 1, 'NUMBER': 1, 'TIMES': 1, 'EQUALS': 1, 'PLUS': 1, 'LPAREN': 1, 'MINUS': 1, 'NAME': 1}
_lexreflags   = 0
_lexliterals  = ''
_lexstateinfo = {'INITIAL': 'inclusive'}
_lexstatere   = {'INITIAL': [('(?P<t_NUMBER>\\d+)|(?P<t_newline>\\n+)|(?P<t_NAME>[a-zA-Z_][a-zA-Z0-9_]*)|(?P<t_LPAREN>\\()|(?P<t_TIMES>\\*)|(?P<t_PLUS>\\+)|(?P<t_RPAREN>\\))|(?P<t_MINUS>-)|(?P<t_EQUALS>=)|(?P<t_DIVIDE>/)', [None, ('t_NUMBER', 'NUMBER'), ('t_newline', 'newline'), (None, 'NAME'), (None, 'LPAREN'), (None, 'TIMES'), (None, 'PLUS'), (None, 'RPAREN'), (None, 'MINUS'), (None, 'EQUALS'), (None, 'DIVIDE')])]}
_lexstateignore = {'INITIAL': ' \t'}
_lexstateerrorf = {'INITIAL': 't_error'}
_lexstateeoff = {}
